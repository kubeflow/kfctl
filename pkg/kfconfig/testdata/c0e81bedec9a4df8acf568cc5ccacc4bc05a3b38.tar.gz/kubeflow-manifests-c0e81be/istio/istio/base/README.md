# Manifest for Istio in Kubeflow

- `install` dir contains the manifest to install Istio
- kf-istio-resources.yaml has
  - Gateway for routing
  - VirtualService for Grafana
  - ServiceEntry and VirtualService for egress traffic
